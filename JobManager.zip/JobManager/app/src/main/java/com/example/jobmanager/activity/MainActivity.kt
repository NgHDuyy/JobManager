package com.example.jobmanager.activity

import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import android.view.Menu
import android.view.MenuItem
import com.example.jobmanager.model.Job
import com.example.jobmanager.adapter.JobAdapter
import com.example.jobmanager.presenter.JobPresenter
import com.example.jobmanager.R
import com.example.jobmanager.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val listJob: ArrayList<Job> = arrayListOf()

    private lateinit var jobPresenter : JobPresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        jobPresenter = JobPresenter(this)

        binding.rcvJob.layoutManager =
            LinearLayoutManager(this)
        binding.rcvJob.adapter = JobAdapter(this, listJob, jobPresenter)

        binding.add.setOnClickListener { view ->
            jobPresenter.nextActivity()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_clear -> {
                jobPresenter.deleteAll()
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}