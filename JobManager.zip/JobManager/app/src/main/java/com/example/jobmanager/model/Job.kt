package com.example.jobmanager.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "jobs")
class Job(
    @PrimaryKey(autoGenerate = true)
    var id: Int?,

    var time: String?,
    var content: String?
)