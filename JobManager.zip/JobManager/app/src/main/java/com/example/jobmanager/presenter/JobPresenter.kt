package com.example.jobmanager.presenter

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.room.Room
import com.example.jobmanager.R
import com.example.jobmanager.activity.AddJobActivity
import com.example.jobmanager.database.JobDatabase
import com.example.jobmanager.model.Job

class JobPresenter(val context: Context) {

    private val db = Room.databaseBuilder(
        context,
        JobDatabase::class.java, "jobs"
    ).allowMainThreadQueries().build()

    fun addJob(job: Job) {
        db.jobDao().insertJob(job)
    }

    fun getAllJob(): ArrayList<Job> {
        return db.jobDao().getAllJob() as ArrayList<Job>
    }

    fun deleteJob(job: Job) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.layout_custom_dialog)

        val window = dialog.window ?: return

        window.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window.setGravity(Gravity.BOTTOM)

        dialog.setCancelable(false)

        val title: TextView = dialog.findViewById(R.id.question)
        val cancel: TextView = dialog.findViewById(R.id.cancel)
        val accept: TextView = dialog.findViewById(R.id.accept)

        title.text = "Xóa nhắc nhở?"

        cancel.setOnClickListener {
            dialog.dismiss()
        }

        accept.setOnClickListener {
            db.jobDao().delete(job)
            Toast.makeText(context, "Đã xóa!", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.show()

    }

    fun deleteAll() {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.layout_custom_dialog)

        val window = dialog.window ?: return

        window.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window.setGravity(Gravity.BOTTOM)

        dialog.setCancelable(false)

        val title: TextView = dialog.findViewById(R.id.question)
        val cancel: TextView = dialog.findViewById(R.id.cancel)
        val accept: TextView = dialog.findViewById(R.id.accept)

        title.text = "Xóa tất cả nhắc nhở?"

        cancel.setOnClickListener {
            dialog.dismiss()
        }

        accept.setOnClickListener {
            db.jobDao().deleteAll()
            Toast.makeText(context, "Đã xóa!", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.show()
    }

    fun nextActivity() {
        context.startActivity(Intent(context, AddJobActivity::class.java))
    }
}